import numpy as np
import math
from Testing.eRNN_R4 import *
from Functions.DataCloud_V4 import *
from Functions.RLS import *
import copy

def RunTag(filename=None, feedback=None, wtaG=None, wtaP=None):
    # Uma pasta de resultados por configuração (feedback, wtaG, wtaP)
    feedback = FEEDBACK if feedback is None else feedback
    wtaG = WTAG if wtaG is None else wtaG
    wtaP = WTAP if wtaP is None else wtaP
    return f'{filename}_{feedback}_G{int(wtaG)}P{int(wtaP)}'

def _XID(cloud):
    # Identidade de origem de cada amostra do grânulo (grânulos criados antes deste registro: o próprio ID)
    xid = getattr(cloud, 'xid', None)
    if xid is None or len(xid) != len(cloud.x): return [cloud.ID] * len(cloud.x)
    return list(xid)

def RefEoL(sig, eol, kX, strict=False, frac=False):
    '''
    Referência da RUL real baseada no limiar de EoL (eq. 12): RUL_real(k) = iEoL - k,
    com iEoL = primeira amostra em que o HI <= eol e k o instante de cada amostra (kX, 4ª saída de PrepareData).
    O AutoCloud calcula rulR = ref - self.k, com self.k = j + 2 na iteração j; logo ref = iEoL - kX[0] + 2.
    Retorna:
        ref : referência passada ao AutoCloud
        J   : nº de iterações com RUL real >= 1 (instantes k < iEoL)
        L   : limite da RUL prevista (lim), igual ao nº de amostras a partir de kX[0]
    Se o fluxo de amostras termina antes de iEoL - 1 (nO grande): strict=True -> ValueError; senão, aviso.
    frac=True: EoL real fracionário por interpolação linear entre iEoL - 1 e iEoL (ref não inteiro), consistente com
               a RUL prevista fracionária do AutoCloud(rul_frac=True). J e L não mudam.
    '''
    sig = np.asarray(sig, dtype=float)
    kX = np.asarray(kX, dtype=int)
    if not np.any(sig <= eol): raise ValueError('O HI nunca atinge o limiar de EoL.')
    iEoL = int(np.argmax(sig <= eol))
    if kX[0] >= iEoL: raise ValueError(f'A primeira amostra (k = {kX[0]}) já está no EoL (iEoL = {iEoL}).')
    if kX[-1] < iEoL - 1:
        msg = (f'O fluxo termina em k = {kX[-1]}, antes do EoL (iEoL = {iEoL}): '
               f'a última RUL real avaliada é {iEoL - kX[-1]} (reduza nO).')
        if strict: raise ValueError(msg)
        print('Aviso: ' + msg)
    ref = iEoL - int(kX[0]) + 2
    if frac and iEoL > 0 and sig[iEoL - 1] > sig[iEoL]:
        ref = ref - 1 + float((sig[iEoL - 1] - eol) / (sig[iEoL - 1] - sig[iEoL]))
    return ref, int(np.sum(kX < iEoL)), len(sig) - int(kX[0])

class AutoCloud:
	'''
	rho dinâmico (granularidade do intervalo de predição), ajustado a cada iteração pelo Princípio da
	Granularidade Justificável em modo online:
		- rho começa em 0; a predição do passo k usa o rho escolhido com os passos anteriores (causal);
		- para cada candidato da grade rho_grid (log-espaçada entre rho_min e rho_max, n_rho valores),
		  o intervalo do passo k é calculado e, quando o valor real é conhecido, acumulam-se cobertura e
		  especificidade com fator de esquecimento lam (1.0 = todos os passos com o mesmo peso);
		- V(rho) = média(cov) * média(sp) (abordagem do artigo); rho_{k+1} = argmax V (empate: menor rho);
		  se nenhum candidato cobriu ainda (V = 0), rho é mantido;
		- V é o valor máximo do passo e Vsum o acumulado de V.
	rho_target:
		'HI' : intervalo do HI um passo à frente; valor real conhecido no passo seguinte (causal); Range = 1.
		'RUL': intervalo da RUL; usa a RUL real (ref - k), que depende do EoL conhecido só ao fim da vida
		       (modo offline/oráculo, para análise); Range = lim. Custo: n_rho previsões completas por passo.
	'''
	def __init__(self,m,nI=1,nR=[1],nO=1,ηS=[0.1,0.1,0.1],
			  tau=1,eol=0,ref=0,act='tanh',st=0,end=0,
			  wtaG=True,wtaP=True,store=True,feedback='symmetric',mO=0,
			  rho=1e-3,lam=1.0,intr_state='reset',
			  rho_dyn=True,rho_eta=0.2,rho_T=0.3,rho_beta=0.0,rho_min=1e-3,rho_max=10.0,sp_range=1.0,
			  rls_mode ='log',nf_rls = 3, ff_rls=1, dt_rls = 1e3,
			  rul_bounds='network', rul_growth='sqrt', rho_rul=None,
			  rul_eclip='none', rul_frac=False
			  ):

		# rho: múltiplo do erro estimado do HI no intervalo de RULInterv (protocolo 3); valor inicial se rho_dyn=True
		self.rho = rho
		# rho dinâmico (sugestão 3): subida de gradiente online em V = média(cov*sp) do HI.
		# A cada passo k, conhecido o erro real |e_k| e o erro estimado e_k usado no intervalo, com escore s_k = |e_k|/e_k:
		#   v_k(rho) = sigma((rho - s_k)/T) * (1 - 2*rho*e_k/R)        (cobertura suavizada * especificidade)
		#   g_k = sigma'(.)/T * (1 - 2*rho*e_k/R) - sigma(.) * 2*e_k/R
		#   m_k = beta*m_{k-1} + (1-beta)*g_k  (média do gradiente com esquecimento);  rho <- clip(rho + eta*m_k)
		# Causal: o rho do passo k+1 usa apenas passos até k. T é adimensional (escala do escore).
		self.rho_dyn = rho_dyn
		self.rho_eta, self.rho_T, self.rho_beta = rho_eta, rho_T, rho_beta
		self.rho_min, self.rho_max, self.sp_range = rho_min, rho_max, sp_range
		self._rho_m = 0.0                   # gradiente médio (momento)
		self.ehat_last = None               # erro estimado usado no intervalo do HI do passo atual
		self.rho_used = np.array([])        # rho usado em cada passo
		self.rho_grad_hist = np.array([])
		# Estado recorrente intervalar em RULInterv: 'carry' (propagado entre os passos da previsão, limites garantidos
		# para toda a sequência de janelas intervalares) ou 'reset' (reiniciado no estado pontual a cada passo: o intervalo
		# de saída reflete apenas a incerteza da janela de entrada do passo)
		if intr_state not in ('carry', 'reset'):
			raise ValueError("intr_state deve ser 'carry' ou 'reset'.")
		self.intr_state = intr_state
		# Limites das trajetórias da RUL intervalar (RULInterv):
		#   'network': análise intervalar da rede (y_inf, y_sup);  'error': predição -/+ rho * erro estimado * g(n),
		#   com g(n) = 1 ('const'), sqrt(n) ('sqrt') ou n ('lin'), n = passos à frente (n = 1: mesmo intervalo do HI)
		if rul_bounds not in ('network', 'error'):
			raise ValueError("rul_bounds deve ser 'network' ou 'error'.")
		if rul_growth not in ('const', 'sqrt', 'lin'):
			raise ValueError("rul_growth deve ser 'const', 'sqrt' ou 'lin'.")
		self.rul_bounds, self.rul_growth = rul_bounds, rul_growth
		# rho_rul: escala da incerteza usada na RUL intervalar (limites em 'error'; intervalos injetados na janela em 'network').
		# None = usa o rho do HI (comportamento anterior). O intervalo do HI do passo usa sempre rho (fixo ou dinâmico).
		if rho_rul is not None and not rho_rul >= 0: raise ValueError('rho_rul deve ser >= 0 (ou None).')
		self.rho_rul = rho_rul
		# rul_eclip: valor do HI em que o modelo de erro é avaliado nas trajetórias da RUL intervalar (evita extrapolação
		#   do RLS para valores de HI ainda não observados; causal, usa apenas hiR até k):
		#   'none'     -> ê(x_pred) (comportamento anterior)
		#   'observed' -> ê(clip(x_pred, min(hiR), max(hiR)))
		#   'last'     -> ê(h_k), último HI observado (meia-largura constante ao longo da trajetória)
		#   O intervalo do HI do passo (n = 1) usa sempre ê(x_pred) e não é alterado.
		if rul_eclip not in ('none', 'observed', 'last'):
			raise ValueError("rul_eclip deve ser 'none', 'observed' ou 'last'.")
		self.rul_eclip = rul_eclip
		# rul_frac: RUL fracionária por interpolação linear do cruzamento do EoL entre os passos n-1 e n
		#   (False: RUL inteira = primeiro n com y <= EoL, comportamento anterior)
		self.rul_frac = bool(rul_frac)
		# Sequência de rolamentos (SimSequence): k_seg = deslocamento de k no início do rolamento atual (0 no primeiro),
		# de modo que RUL real, tempo e pesos do WAPE sejam locais ao rolamento; frozen = modelo congelado (Freeze)
		self.k_seg = 0
		self.k_seg_start = 1                # k (global) da primeira amostra do rolamento atual
		self.seg_name = None
		self.segments = {}                  # resultados arquivados de cada rolamento (EndSegment)
		self.frozen = False
		self.c_retired = []                # grânulos substituídos em fusões (estado no momento da fusão; gráficos)
		self.lam = lam
		self.S_w = 0.0                      # soma (com esquecimento) dos pesos dos passos
		self.Vsum = 0.0
		self.rho_hist = np.array([])        # rho usado na predição de cada passo
		self.V_hist = np.array([])          # V após cada atualização
		self.Vsum_hist = np.array([])
		self._pending = None                # intervalos dos candidatos aguardando o valor real
		self.vSum = 0
		self.st = st
		self.act = act
		self.end = end
		# Janelas do HI (mesmas de PrepareData): Y_k com nI valores; Z_k com mO passados (incluindo h_k) e nO futuros.
		# Saída das RNNs: nOut = mO + nO valores; a predição um passo à frente h_{k+1} é a coordenada mO.
		self.nI = nI
		self.nR = nR
		self.nO = nO
		self.mO = mO
		self.nOut = nO + mO
		self.sd = 42
		self.feedback = feedback

		if ηS[0] < 1:
			self.N1 = ηS[0]
		elif ηS[0]>=1:
			self.N1 = 1/(10**ηS[0])

		if ηS[1] < 1:
			self.N2 = ηS[1]
		elif ηS[1]>=1:
			self.N2 = 1/(10**ηS[1])

		if ηS[2] < 1:
			self.N3 = ηS[2]
		elif ηS[2]>=1:
			self.N3 = 1/(10**ηS[2])		

		self.tau = tau
		self.eol = eol
		self.store = store
		self.gCreated = 0
		self.c= np.array([])
		self.alfa= np.array([0.0],dtype=float)
		self.intersection = np.zeros((1,1),dtype=int)
		self.listIntersection = np.zeros((1),dtype=int)
		self.matrixIntersection = np.zeros((1,1),dtype=int)
		self.relevanceList = np.zeros((1),dtype=int)
		self.classIndex = []
		self.k=1
		self.m = m
		self.cloud_activation = []
		self.aux = np.array([])
		self.DSIs = [np.array([]) for i in range(nI)]

		if self.act == 0:
			self.act = 'tanh'
		elif self.act == 1:
			self.act = 'relu'
		elif self.act == 2:
			self.act = 'sigmoid'

		self.eolX = 0
		self.HI = np.array([])
		self.DSI = np.array([])
		self.eolDSI = 0
		self.HIp = np.array([])
		self.cycleP=np.array([])

		self.t = np.array([])
		self.rulL = np.array([])
		self.rulP = np.array([])
		self.rulU = np.array([])
		self.rulR = np.array([])
		# 1 quando a trajetória (inferior, pontual, superior) não atinge o EoL e a RUL é truncada em lim
		self.rulCapL = np.array([], dtype=int)
		self.rulCapP = np.array([], dtype=int)
		self.rulCapU = np.array([], dtype=int)
		self.ref = ref
		self.rulR_Train = np.array([])
		self.lim = 160

		self.hiR = np.array([])
		self.hiP = np.array([])
		self.hiL = np.array([])
		self.hiU = np.array([])

		self.wape_RUL_hist = np.array([])
		self.wape_RUL = 0
		self.eRul_Sum = 0
		self.eRul_Diff = 0

		self.wape_HI_hist = np.array([])
		self.wape_HI = 0
		self.eHI_Sum = 0
		self.eHI_Diff = 0

		self.wape_HI_hist2 = np.array([])
		self.wape_HI2 = 0
		self.eHI_Sum2 = 0
		self.eHI_Diff2 = 0

		self.eP = np.array([])
		self.eR = np.array([])
		self.wtaG = wtaG
		self.wtaP = wtaP
		self.xR = 0
		self.Dmax = 0

		if rls_mode == 'log':
			self.rls = RLS_LogarithmicRegressor(ff=ff_rls,dt=dt_rls)
		elif rls_mode == 'pol':
			self.rls = RLS(nf=nf_rls,ff=ff_rls,dt=dt_rls)

		self.sp = 0
		self.cov = 0
		self.V = 0
		self.sp_hist = np.array([])
		self.cov_hist = np.array([])
		self.V_hist = np.array([])

		self.dim = None
		self.gm = None
		self.mean_gm = 0
		self.meant_gm = 0
		self.var_gm = 0
		self.xMax_gm = None
		self.Rmax_gm = 0
		self.Vmax_gm = 0

		self.transfer = False

	def UpdateRLS(self,mode='RUL'):

		if mode == 'RUL':
			#x = self.rulP[-1]
			#eP = self.rls.predict(x)
			#eR = np.abs(self.rulP[-1]-self.rulR[-1])
			#self.rls.update(x,eR)
			#self.RUL_Granularity()

			x = self.hiP[-1]
			if x < 0:
				x = 1e-9
			eP = self.rls.predict(x)
			eR = np.abs(self.hiP[-1]-self.hiR[-1])
			self.rls.update(x,eR)
			self.RUL_Granularity()
			# Valor real do HI conhecido: atualiza o rho do próximo passo
			if self.rho_dyn and self.ehat_last is not None:
				self.UpdateRhoGrad(eR, self.ehat_last)
				self.ehat_last = None

		if mode == 'HI':
			x = self.hiP[-1]
			if x < 0:
				x = 1e-9
			eP = self.rls.predict(x)
			eR = np.abs(self.hiP[-1]-self.hiR[-1])
			if not self.frozen: self.rls.update(x,eR)   # congelado: modelo do erro e rho mantidos
			self.HI_Granularity()
			# Valor real do HI conhecido: atualiza o rho do próximo passo
			if self.rho_dyn and not self.frozen and self.ehat_last is not None:
				self.UpdateRhoGrad(eR, self.ehat_last)
				self.ehat_last = None

		self.eP = np.append(self.eP,eP)
		self.eR = np.append(self.eR,eR)

	def UpdateRhoGrad(self, e, ehat):
		# Subida de gradiente online em v_k(rho) = sigma((rho - s_k)/T) * (1 - 2*rho*ehat/R), s_k = |e_k|/ehat
		if ehat <= 0:                                   # modelo de erro ainda não treinado: rho mantido
			self.rho_grad_hist = np.append(self.rho_grad_hist, 0.0)
			return
		s = abs(e) / ehat
		z = (self.rho - s) / self.rho_T
		sig = 0.5 * (1.0 + np.tanh(0.5 * z))            # sigmoide numericamente estável
		sp_raw = 1.0 - 2.0 * self.rho * ehat / self.sp_range
		g = sig * (1.0 - sig) / self.rho_T * sp_raw - sig * 2.0 * ehat / self.sp_range
		self._rho_m = self.rho_beta * self._rho_m + (1.0 - self.rho_beta) * g
		self.rho = float(np.clip(self.rho + self.rho_eta * self._rho_m, self.rho_min, self.rho_max))
		self.rho_grad_hist = np.append(self.rho_grad_hist, g)

	def HI_Granularity(self):

		hiR,hiL,hiU,hiP = self.hiR,self.hiL,self.hiU,self.hiP

		#Range = np.max(hiR) - np.min(hiR)
		Range = 1 - 0
		cov, sp, Vsum = np.array([]), np.array([]), 0
		
		for hR,hL,hU in zip(hiR,hiL,hiU):
			if hR>= hL and hR<= hU:
				cov = np.append(cov,1)
			else:
				cov = np.append(cov,0)
			spVal = max(0, 1 - (hU-hL)/Range )
			sp = np.append(sp, spVal)
			Vsum +=  cov[-1]*sp[-1]
		self.sp = sp.mean()
		self.cov = cov.mean()
		self.sp_hist = sp
		self.cov_hist = cov
		#self.V = cov.mean() * sp.mean()
		self.V = (cov * sp).mean() 
		self.Vsum = Vsum

	def RUL_Granularity(self):
		rulR,rulL,rulP,rulU = self.rulR,self.rulL,self.rulP,self.rulU
		Range = np.max(rulR) - np.min(rulR)
		cov, sp, Vsum = np.array([]), np.array([]), 0

		for rR,rL,rU in zip(rulR,rulL,rulU):
			if rR>= rL and rR<= rU:
				cov = np.append(cov,1)
			else:
				cov = np.append(cov,0)
			spVal = max(0, 1 - (rU-rL)/Range )
			sp = np.append(sp, spVal)
			Vsum +=  cov[-1]*sp[-1]

			self.sp = sp.mean()
			self.cov = cov.mean()
			self.sp_hist = sp
			self.cov_hist = cov
			#self.V = cov.mean() * sp.mean()
			self.V = (cov * sp).mean() 
			self.Vsum = Vsum

	def UpdateRho(self, truth):
		# Atualização online do rho: acumula cov/sp de cada candidato com o valor real e escolhe o melhor V
		target, L, U = self._pending[:3]
		self._pending = None
		Range = 1.0 if target == 'HI' else float(self.lim)
		cov = ((L <= truth) & (truth <= U)).astype(float)
		sp = np.maximum(0.0, 1.0 - (U - L) / Range)
		self.S_w = self.lam * self.S_w + 1.0
		self.S_cov = self.lam * self.S_cov + cov
		self.S_sp = self.lam * self.S_sp + sp
		self.V_grid = (self.S_cov / self.S_w) * (self.S_sp / self.S_w)
		i = int(np.argmax(self.V_grid))          # grade crescente: em empate fica o menor rho
		if self.V_grid[i] > 0:
			self.rho = float(self.rho_grid[i])
		self.V = float(self.V_grid[i])
		self.Vsum += self.V
		self.V_hist = np.append(self.V_hist, self.V)
		self.Vsum_hist = np.append(self.Vsum_hist, self.Vsum)

	def WAPE_RUL(self):
		yR, yP, t = self.rulR[-1], self.rulP[-1], (self.k - self.k_seg)**2
		self.eRul_Diff = np.abs(yR*t - yP*t) + self.eRul_Diff
		self.eRul_Sum = np.abs(yR*t) + self.eRul_Sum
		self.wape_RUL = self.eRul_Diff/self.eRul_Sum

		if self.store:
			self.wape_RUL_hist = np.append(self.wape_RUL_hist,self.wape_RUL)

	def WAPE_HI(self):
		yR, yP, t = self.hiR[-1], self.hiP[-1], (self.k - self.k_seg)**2
		self.eHI_Diff = np.abs(yR*t - yP*t) + self.eHI_Diff
		self.eHI_Sum = np.abs(yR*t) + self.eHI_Sum
		self.wape_HI = self.eHI_Diff/self.eHI_Sum

		if self.store:
			self.wape_HI_hist = np.append(self.wape_HI_hist,self.wape_HI)

	def teda_WAPE(self):
		self.WAPE_RUL()
		self.WAPE_HI()

	def PredictWindow(self,y,show=False):
		ws = self.alfa/np.sum(self.alfa)
		p = (np.array([w*cloud.rnn.PredictionVector(y) for cloud,w in zip(self.c,ws)]))
		p = np.sum(p,axis=0)
		return p	

	def	WAPE_HI2(self,y,zR):
		zP = self.PredictWindow(y,show=False)
		t = (self.k - self.k_seg)**2
		self.eHI_Diff2 = np.sum(np.abs(zR*t - zP*t)) + self.eHI_Diff2
		self.eHI_Sum2 = np.sum(np.abs(zR*t)) + self.eHI_Sum2
		self.wape_HI2 = self.eHI_Diff2/self.eHI_Sum2

		if self.store:
			self.wape_HI_hist2 = np.append(self.wape_HI_hist2,self.wape_HI2)	
			
	def AdjustCloudMaster(self,t,x):

			clouds = self.c
			points = []
			axes = np.eye(len(self.c[0].mean))
			for cloud in clouds:
				for axis in axes:
					points.append(cloud.mean + axis * cloud.R)
					points.append(cloud.mean - axis * cloud.R)
			points = np.array(points)
	
			p1 = points[np.argmax(np.linalg.norm(points - points[0], axis=1))]
			p2 = points[np.argmax(np.linalg.norm(points - p1, axis=1))]
	
			center = (p1 + p2) / 2.0
			radius = np.linalg.norm(p1 - p2) / 2.0
	
			for p in points:
				dist = np.linalg.norm(p - center)
				if dist > radius:
					new_radius = (radius + dist) / 2.0
					center = center + (p - center) * (new_radius - radius) / dist
					radius = new_radius
	
			for cloud in clouds:
				dist = np.linalg.norm(cloud.mean - center)
				if dist + cloud.R > radius:
					diff = dist + cloud.R - radius
					direction = (center - cloud.mean) / dist if dist > 0 else np.eye(len(center))[0]   # vetor unitário na dimensão do DSI
					center = center - direction * (diff / 2.0)
					radius += diff / 2.0
		
			
			dim = self.gm.dim
			self.gm.mean = center
			self.gm.R = radius
			self.gm.Rmax = radius
			self.gm.V = (math.pi ** (dim / 2)) / math.gamma((dim / 2) + 1) * (radius ** dim)
			self.gm.n = self.k
			if self.store:
				self.gm.t.append(t)
				if self.k > 1:
					self.gm.x.append(x)
					
	def CalculateSpCov(self):
		vec = []
		for cloud in self.c:
			cloud.cov = cloud.n/self.gm.n
			cloud.sp_sum += max(0,1-cloud.V/self.gm.V)
			cloud.sp = cloud.sp_sum/self.gm.n
			vec.append(cloud.sp)
	
	def CreateCloud(self,x,t,store=False):
		self.gCreated = self.gCreated + 1
		cloud = DataCloud(x,(self.k-1),self.gCreated,self.rho,self.m,nI=self.nI,nR=self.nR,nO=self.nOut,
					ηS=[self.N1,self.N2,self.N3],tau=self.tau,sd=self.sd,act=self.act,feedback=self.feedback,nPast=self.mO)
		if store:
			cloud.t.append(self.k)
		self.c = np.append(self.c,cloud)

	def CloudOtimization(self):
		vec = np.array([])
		for cloud in self.c:
			cloud.sp = cloud.sp/(self.k-1)
			cloud.cov = cloud.cov/(self.k-1)
			cloud.v = cloud.sp * cloud.cov
			vec = np.append(vec, cloud.v)
		self.vSum = np.sum(vec)

	def Adapt(self,y,z, show=False):
		n = self.c[0].rnn.n
		self.HI = np.append(self.HI,z[n])
		self.hiR = np.append(self.hiR,z[n])
		# WAPE do HI com o valor real do mesmo passo (hiP_k vs hiR_k): calculado aqui, após o valor real ser conhecido
		if self.k - self.k_seg > 2:
			self.WAPE_HI()
		# Valor real do passo conhecido: atualiza o rho que será usado na próxima predição
		#if self._pending is not None:
		#	self.UpdateRho(z[n] if self._pending[0] == 'HI' else self._pending[3])
		for i,cloud in enumerate(self.c):
			if self.alfa[i] > 0:
				if self.frozen: cloud.rnn.Step(y)       # congelado: só avança o estado recorrente
				else: cloud.rnn.fit(y,z)
				if show: print(cloud.ID,'yes')
				
			else:
				if show: print(cloud.ID,'No')

	
	def Predict(self,y,show=False):
		ws = self.alfa/np.sum(self.alfa)
		p = (np.array([w*cloud.rnn.Predict(y) for cloud,w in zip(self.c,ws)]))
		p = np.sum(p)
		return p

	def DefRnnParams(self, cloud):
		if len(self.c)>1:
			params = self.c[-2].rnn.ReturnParameters()
		if len(self.c)==1:
			params = self.c[-1].rnn.ReturnParameters()
		cloud.rnn.ReceiveParameters(params)

	def MergeCloudsRNN(self, c1, c2, c3):
		p1 = c1.rnn.ReturnParameters()
		p2 = c2.rnn.ReturnParameters()
		params = []
		for item1, item2 in zip(p1, p2):
			if isinstance(item1, list):
				# Média elemento a elemento para cada camada l (wR, wI, pS, qS, hP, etc.)
				camadas_media = [(l1 + l2) / 2.0 for l1, l2 in zip(item1, item2)]
				params.append(camadas_media)
			else:
				# Média direta para arrays NumPy simples (wO, x)
				params.append((item1 + item2) / 2.0)

		c3.rnn.ReceiveParameters(params)


	def RULSingle(self,X,lim=None,show=False):
			if lim==None:
				lim = 160
			xP = X.copy()
			predict = True
			rulP = 0
			Check = True
			PredVal = np.zeros(1)
			cont = True

			while predict:
				if self.wtaP:
					self.alfa = np.where(self.alfa<np.max(self.alfa),0,self.alfa)
				ws = self.alfa/np.sum(self.alfa)

				Pred = [w*c.rnn.PredictSingle(xP,True) for w,c in zip(ws,self.c)]
				yP = sum(Pred)

				if cont:
					self.hiP = np.append(self.hiP,yP)
					self.hiL = np.append(self.hiL,yP)
					self.hiU = np.append(self.hiU,yP)
					cont = False

				xP = np.delete(np.append(xP,yP),0)

				if Check:
					rulP = rulP + 1
				else:
					rulP = rulP

				if rulP > lim:
					Check = False
					rulP = lim
				else: None

				if yP <= self.eol:
					Check = False
					
				else: None


				if not Check: 
					break
				else: None

				
			for cloud in self.c:
				cloud.rnn.Restore()

			self.t = np.append(self.t,self.k - 2 - self.k_seg)
			self.rulR = np.append(self.rulR,self.ref - (self.k - self.k_seg))
			self.rulP = np.append(self.rulP,rulP)
			self.rulL = np.append(self.rulL,rulP)
			self.rulU = np.append(self.rulU,rulP)

			for i,cloud in enumerate(self.c):
				if self.alfa[i] > 0:
					cloud.t2.append(self.k - 2 - self.k_seg)
					cloud.rulR = np.append(cloud.rulR,self.ref - (self.k - self.k_seg))
					cloud.rulP = np.append(cloud.rulP,rulP)
					cloud.rulL.append(rulP)
					cloud.rulM.append(rulP)
					cloud.hiM.append(self.hiP[-1])
					cloud.rulU.append(rulP)


	def ErrorModelHI(self, y):
		# Erro absoluto estimado de uma predição de HI de valor y (modelo logarítmico RLS de UpdateRLS(mode='HI'));
		# antes do primeiro ajuste o modelo retorna 0 (intervalo degenerado)
		return abs(self.rls.predict(max(y, 1e-9)))

	def _ErrorRUL(self, y, hk):
		# Erro estimado usado nas trajetórias da RUL intervalar, conforme rul_eclip (hk = último HI observado)
		if self.rul_eclip == 'last':
			return self.ErrorModelHI(hk)
		if self.rul_eclip == 'observed' and np.size(self.hiR) > 0:
			y = min(max(y, float(np.min(self.hiR))), float(np.max(self.hiR)))
		return self.ErrorModelHI(y)

	def _rul_g(self, n):
		# Crescimento da meia-largura com o horizonte n (rul_bounds='error'): erros independentes -> sqrt(n);
		# totalmente correlacionados -> n; sem crescimento -> 1
		return {'const': 1.0, 'sqrt': math.sqrt(n), 'lin': float(n)}[self.rul_growth]

	def RULInterv(self,X,lim=None,show=False):
		'''
		RUL intervalar: previsão recursiva de RULSingle + protocolo 3 (Al-Hmouz et al., 2024, eq. 10) na janela de entrada
		+ análise intervalar da rede (Wang et al., 2024, Lema 1 / Teorema 1) com pesos numéricos.
		A cada passo n:
		  1) janela pontual X_{k+n} -> predição pontual x_{k+n+1} (igual a RULSingle);
		     janela intervalar [X_{k+n}] -> limites [y_inf, y_sup] pela análise intervalar
		     (W+ x_inf - W- x_sup <= W x <= W+ x_sup - W- x_inf em cada camada; estado recorrente conforme intr_state);
		  2) erro estimado do valor previsto: eP_{k+n} = e(x_{k+n+1}) (modelo RLS logarítmico do HI);
		  3) próximas janelas: pontual recebe x_{k+n+1}; intervalar recebe [x_{k+n+1} - rho*eP, x_{k+n+1} + rho*eP]
		     (valores observados permanecem intervalos degenerados; com o avanço, todas as coordenadas viram intervalos);
		  4) RUL: primeiro passo em que y_inf, x_pred e y_sup atingem o EoL -> rulL, rulP, rulU.
		O intervalo do HI do passo (n = 0, janela observada) é [x_pred - rho*eP, x_pred + rho*eP] (eq. 10).

		rul_bounds (construtor) define os limites usados nas trajetórias inferior/superior:
		  'network': y_inf, y_sup da análise intervalar da rede (descrito acima). A largura depende da sensibilidade
		             da rede à sua entrada (pode colapsar em redes profundas com tau grande).
		  'error'  : y_inf/sup_{k+n} = x_pred_{k+n} -/+ rho * eP_{k+n} * g(n), n = 1, 2, ... (passos à frente),
		             com g(n) = 1 ('const'), sqrt(n) ('sqrt') ou n ('lin') conforme rul_growth. Os limites seguem
		             diretamente o modelo de erro e o rho; só a trajetória pontual passa pela rede.
		  Nos dois modos y_inf <= x_pred <= y_sup em todos os passos -> rulL <= rulP <= rulU, e o intervalo do HI
		  do passo (n = 1) é o mesmo.
		rho_rul (construtor): substitui rho nos limites da RUL ('error') ou nos intervalos injetados na janela ('network');
		  None = rho. O intervalo do HI do passo continua [x_pred - rho*eP, x_pred + rho*eP].
		'''
		if lim==None:
			lim = 160
		self.lim = lim
		if self.wtaP:
			self.alfa = np.where(self.alfa<np.max(self.alfa),0,self.alfa)
		ws = self.alfa/np.sum(self.alfa)

		for cloud in self.c:
			cloud.rnn.Restore()
		xP, xL, xU = X.copy(), X.copy(), X.copy()
		Ruls = [0 for i in range(3)]
		CheckRuls = [True for i in range(3)]
		Capped = [0 for i in range(3)]
		first = True
		n = 0                                           # passos à frente na previsão (n = 1 no primeiro)
		rho_r = self.rho if self.rho_rul is None else self.rho_rul
		hk = float(X[-1])                               # último HI observado (h_k)
		Prev = [hk, hk, hk]                             # valores das trajetórias no passo anterior (rul_frac)

		while True:
			n += 1
			if self.rul_bounds == 'error':
				# 1-2) Predição pontual pela rede; limites = predição -/+ rho * erro estimado * g(n)
				yP = sum(w*c.rnn.PredictSingle(xP) for w,c in zip(ws,self.c))
				M = self.rho * self.ErrorModelHI(yP)
				Mn = rho_r * self._ErrorRUL(yP, hk) * self._rul_g(n)
				yL, yU = yP - Mn, yP + Mn
			else:
				if self.intr_state == 'reset':
					for cloud in self.c:
						cloud.rnn.hL2 = [h.copy() for h in cloud.rnn.hP2]
						cloud.rnn.hU2 = [h.copy() for h in cloud.rnn.hP2]
				# 1) Predição pontual e limites da análise intervalar (ep = 0: pesos numéricos)
				yL, yP, yU = sum(w*c.rnn.PredictIntr(xP,xL,xU,0.0,False) for w,c in zip(ws,self.c))
				yL, yU = min(yL, yP), max(yU, yP)          # remove apenas resíduos de arredondamento
				# 2) Erro estimado do valor previsto
				M = self.rho * self.ErrorModelHI(yP)

			if first:
				self.ehat_last = self.ErrorModelHI(yP)      # erro estimado do intervalo do HI deste passo
				self.rho_used = np.append(self.rho_used, self.rho)
				self.hiP = np.append(self.hiP, yP)
				self.hiL = np.append(self.hiL, yP - M)
				self.hiU = np.append(self.hiU, yP + M)
				first = False

			# 3) Próximas janelas: pontual e intervalar (protocolo 3 no novo valor previsto)
			xP = np.delete(np.append(xP, yP), 0)
			if self.rul_bounds == 'network':
				Mr = rho_r * self._ErrorRUL(yP, hk)           # protocolo 3 com a escala da RUL
				xL = np.delete(np.append(xL, yP - Mr), 0)
				xU = np.delete(np.append(xU, yP + Mr), 0)

			# 4) RUL de cada trajetória (inferior, pontual, superior)
			PredVals = (yL, yP, yU)
			for j,_ in enumerate(Ruls):
				if CheckRuls[j]:
					Ruls[j] = Ruls[j] + 1
				if Ruls[j] > lim:
					CheckRuls[j] = False
					Ruls[j] = lim
					Capped[j] = 1
			for j,_ in enumerate(CheckRuls):
				if CheckRuls[j] and PredVals[j] <= self.eol:
					CheckRuls[j] = False
					# Cruzamento entre n-1 e n: RUL = (n - 1) + fração interpolada (passo inteiro se não há queda)
					if self.rul_frac and Prev[j] > self.eol and Prev[j] > PredVals[j]:
						Ruls[j] = (Ruls[j] - 1) + (Prev[j] - self.eol) / (Prev[j] - PredVals[j])
				Prev[j] = PredVals[j]
			if sum(CheckRuls)==0:
				break

		for cloud in self.c:
			cloud.rnn.Restore()

		# HI decrescente e y_inf <= x_pred <= y_sup em todos os passos: rulL <= rulP <= rulU por construção
		self.t = np.append(self.t,self.k - 2 - self.k_seg)
		self.rulR = np.append(self.rulR,self.ref - (self.k - self.k_seg))
		self.rulP = np.append(self.rulP,Ruls[1])
		self.rulL = np.append(self.rulL,Ruls[0])
		self.rulU = np.append(self.rulU,Ruls[2])
		self.rulCapL = np.append(self.rulCapL,Capped[0])
		self.rulCapP = np.append(self.rulCapP,Capped[1])
		self.rulCapU = np.append(self.rulCapU,Capped[2])

		for i,cloud in enumerate(self.c):
			if self.alfa[i] > 0:
				cloud.t2.append(self.k - 2 - self.k_seg)
				cloud.rulR = np.append(cloud.rulR,self.ref - (self.k - self.k_seg))
				cloud.rulP = np.append(cloud.rulP,Ruls[1])
				cloud.rulL.append(Ruls[0])
				cloud.rulM.append(Ruls[1])
				cloud.hiM.append(self.hiP[-1])
				cloud.rulU.append(Ruls[2])

	def RUL_Prediction(self,X,mode='single',lim=None,show=False):
		if mode=='single':
			self.RULSingle(X,lim,show)
		elif mode=='interval':
			self.RULInterv(X,lim,show)
		else:
			raise ValueError("Modo inválido. Escolha 'single' ou 'interval'.")
		# WAPE da RUL: rulR e rulP do mesmo passo já disponíveis; o WAPE do HI é calculado em Adapt
		if self.k - self.k_seg > 2:
			self.WAPE_RUL()

	def AddRUL(self):
		for cloud in self.cloud_activation:
			cloud.rulP = np.append(cloud.rulP,self.rulP[-1])
		self.cloud_activation = []
	
	def MergeClouds(self,X):
		i=0
		while(i<len(self.listIntersection)-1):
			merge=False
			j=i+1
			while(j<len(self.listIntersection)):
				if(self.listIntersection[i] == 1 and self.listIntersection[j] == 1):
					self.matrixIntersection[i,j] = self.matrixIntersection[i,j] + 1
				idI = self.c[i].ID
				idJ = self.c[j].ID
				xMinI = self.c[i].xMin
				xMinJ = self.c[j].xMin
				xMaxI = self.c[i].xMax
				xMaxJ = self.c[j].xMax
				meanI = self.c[i].mean
				meanJ = self.c[j].mean
				meantI = self.c[i].meant
				meantJ = self.c[j].meant
				nI = self.c[i].n
				nJ = self.c[j].n
				tipicalityI = self.c[i].tipicality
				tipicalityJ = self.c[j].tipicality
				trackI = self.c[i].track
				trackJ = self.c[j].track
				varianceI = self.c[i].variance
				varianceJ = self.c[j].variance
				rulLI = self.c[i].rulL
				rulLJ = self.c[j].rulL
				rulUI = self.c[i].rulU
				rulUJ = self.c[j].rulU
				rulMI = self.c[i].rulM
				rulMJ = self.c[j].rulM
				nIntersc = self.matrixIntersection[i,j]
				
				if (nIntersc > (nI - nIntersc) or nIntersc > (nJ - nIntersc)):
					
					merge = True
					self.gCreated = self.gCreated + 1
					n = int(nI + nJ - nIntersc)
					mean = ((nI * meanI) + (nJ * meanJ))/(nI + nJ)
					meant = ((nI * meantI) + (nJ * meantJ))/(nI + nJ)
					variance = ((nI - 1) * varianceI + (nJ - 1) * varianceJ)/(nI + nJ - 2)
					tipicality = ((nI*tipicalityI)+(nJ*tipicalityJ))/(nI + nJ)

					newCloud = DataCloud(X,(self.k-1),self.gCreated,self.rho,self.m,nI=self.nI,nR=self.nR,nO=self.nOut,
									ηS=[self.N1,self.N2,self.N3],tau=self.tau,sd=self.sd,act=self.act,feedback=self.feedback,nPast=self.mO)
					for id in trackI:
						newCloud.track.append(id)
					for id in trackJ:
						newCloud.track.append(id)
						
					newCloud.UpdateDataCloud(n,mean,meant,variance,tipicality,self.k,X)

					x = self.c[i].x + self.c[j].x
					t = self.c[i].t + self.c[j].t
					xid = _XID(self.c[i]) + _XID(self.c[j])
					t2 = self.c[i].t2 + self.c[j].t2

					rulM = rulMI + rulMJ
					rulL = rulLI + rulLJ
					rulU = rulUI + rulUJ
					
					mat = np.array(list(zip(t,x)), dtype=object)
					col = mat[:, 0].astype(int) 
					_, index = np.unique(col, return_index=True)
					result = mat[np.sort(index)]
					t = result[:, 0].tolist()
					x = result[:, 1].tolist()
					xid = [xid[q] for q in np.sort(index)]          # mesma seleção (amostra repetida: origem do 1º grânulo)

					#mat = np.array(list(zip(t2,rulL,rulM,rulU)), dtype=object)
					#col = mat[:, 0].astype(int) 
					#_, index = np.unique(col, return_index=True)
					#result = mat[np.sort(index)]
					#t2   = result[:, 0].tolist()
					#rulL = result[:, 1].tolist()
					#rulM = result[:, 2].tolist()
					#rulU = result[:, 3].tolist()
					if np.linalg.norm(newCloud.mean - self.c[j].xIni) > np.linalg.norm(newCloud.mean - self.c[i].xIni):
						newCloud.xIni = (self.c[j].xIni)
					else: 
						newCloud.xIni = (self.c[i].xIni)

					newCloud.x = x
					newCloud.xMax = 0.5*(self.c[i].xMax + self.c[j].xMax)
					newCloud.xMin = 0.5*(self.c[i].xMin + self.c[j].xMin)
					newCloud.t = t
					newCloud.xid = xid
					for old in (self.c[i], self.c[j]):              # guardados para os gráficos (identidade de origem)
						old.k_retired = self.k
						old.merged_into = newCloud.ID
						self.c_retired.append(old)
					#newCloud.t2 = t2
					#newCloud.rulL = rulL
					#newCloud.rulM = rulM
					#newCloud.rulU = rulU
					#xMin = np.minimum(xMinI, xMinJ)
					#xMax = np.maximum(xMaxI, xMaxJ)
					#newCloud.xMin = xMin
					#newCloud.xMax = xMax	
					newCloud.AdjustBounds(X,self.k)
						
					self.MergeCloudsRNN(self.c[i],self.c[j],newCloud)
					newCloud.merge = f'G{self.gCreated}: G{idI}+G{idJ}'

					self.cloud_activation.append(newCloud)
					self.aux = np.append(self.aux,newCloud.ID)

					self.listIntersection = np.concatenate((self.listIntersection[0 : i], np.array([1]), self.listIntersection[i + 1 : j],self.listIntersection[j + 1 : np.size(self.listIntersection)]),axis=None)
					self.c = np.concatenate((self.c[0 : i ], np.array([newCloud]), self.c[i + 1 : j],self.c[j + 1 : np.size(self.c)]),axis=None)
					M0 = self.matrixIntersection
					M1=np.concatenate((M0[0 : i , :],np.zeros((1,len(M0))),M0[i + 1 : j, :],M0[j + 1 : len(M0), :]))
					M1=np.concatenate((M1[:, 0 : i ],np.zeros((len(M1),1)),M1[:, i+1 : j],M1[:, j+1 : len(M0)]),axis=1)
					col = (M0[:, i] + M0[:, j])*(M0[: , i]*M0[:, j] != 0)
					col = np.concatenate((col[0 : j], col[j + 1 : np.size(col)]))
					lin = (M0[i, :]+M0[j, :])*(M0[i, :]*M0[j, :] != 0)
					lin = np.concatenate((lin[ 0 : j], lin[j + 1 : np.size(lin)]))
					M1[:,i]=col
					M1[i,:]=lin
					M1[i, i + 1 : j] = M0[i, i + 1 : j] + M0[i + 1 : j, j].T;   
					self.matrixIntersection = M1

				j += 1
			if(merge): 
				i = 0
			else: i += 1

	def SimGranularRUL(self,J,L,X,Y,Z):
		for j,_ in enumerate(X[:J]):
			self.run(X[j])
			self.RUL_Prediction(Y[j],mode='interval',lim=L,show=False)
			self.WAPE_HI2(Y[j],Z[j])
			self.Adapt(Y[j],Z[j])
			self.UpdateRLS(mode='HI')

	def SimGranulation(self,X,J=None):
		'''
		Simula apenas a granulação do DSI (AutoCloud), sem predição de HI/RUL nem treino das RNNs.
		X: DSI, uma amostra por linha. Aceita a saída X de PrepareData (mesmos grânulos de SimGranularRUL)
		   ou o RS bruto (DataFrame ou array: granula todas as amostras).
		J: número de amostras granuladas; None = todas (J de RefEoL reproduz o trecho de SimGranularRUL).
		'''
		X = np.asarray(X, dtype=float)
		if X.ndim == 1: X = X.reshape(-1, 1)
		for x in X[:J]:
			self.run(x)

	# ------------------------------------------------------------------------------------------------------------
	# Sequência de rolamentos: aprender com um rolamento e prosseguir para o seguinte (transfer 'adapt' ou 'freeze')
	# ------------------------------------------------------------------------------------------------------------
	_SEG_LOGS = ['t','rulL','rulP','rulU','rulR','rulCapL','rulCapP','rulCapU','hiR','hiP','hiL','hiU','HI',
				 'wape_RUL_hist','wape_HI_hist','wape_HI_hist2','eP','eR','rho_used','rho_hist','rho_grad_hist',
				 'sp_hist','cov_hist','V_hist','Vsum_hist']

	def Freeze(self, flag=True):
		'''
		Congela (flag=True) ou libera o modelo. Congelado:
		  - grânulos: sem criação, atualização (média, variância, raio) ou fusão; cada amostra é atribuída aos grânulos
		    que a aceitam (mesmo critério de excentricidade), com pesos = tipicidade calculada com as estatísticas
		    congeladas (soma ponderada, como no modelo treinado); se nenhum aceita, ao grânulo mais típico;
		  - RNNs: sem aprendizado (pesos e traços fixos); o estado recorrente avança com Step;
		  - modelo do erro (RLS) e rho: fixos.
		'''
		self.frozen = bool(flag)

	def NewSegment(self, name, ref, reset_state=True):
		'''
		Início de um novo rolamento: k_seg = k - 1 (RUL real = ref - (k - k_seg), tempo t = k - 2 - k_seg e pesos
		do WAPE (k - k_seg)^2 locais ao rolamento), registros de predição/WAPE/V reiniciados e, com reset_state, estado
		recorrente das RNNs reiniciado (pesos mantidos). Grânulos, pesos, modelo do erro e rho são mantidos.
		'''
		self.seg_name, self.ref = name, ref
		self.k_seg, self.k_seg_start = self.k - 1, self.k
		for f in self._SEG_LOGS:
			setattr(self, f, np.array([], dtype=int) if f.startswith('rulCap') else np.array([]))
		self.wape_RUL = self.eRul_Sum = self.eRul_Diff = 0
		self.wape_HI = self.eHI_Sum = self.eHI_Diff = 0
		self.wape_HI2 = self.eHI_Sum2 = self.eHI_Diff2 = 0
		self.sp = self.cov = self.V = 0
		self.Vsum = 0.0
		self.ehat_last = None
		for cloud in self.c:                          # registros de RUL por grânulo (só para os gráficos)
			cloud.t2, cloud.rulM, cloud.rulL, cloud.rulU, cloud.hiM = [], [], [], [], []
			cloud.rulR, cloud.rulP = np.array([]), np.array([])
			if reset_state: cloud.rnn.ResetState()

	def EndSegment(self):
		'''Arquiva os registros e métricas do rolamento atual em self.segments[seg_name] e retorna o dicionário.'''
		seg = {f: np.copy(getattr(self, f)) for f in self._SEG_LOGS}
		seg.update(name=self.seg_name, ref=self.ref, k_seg=self.k_seg, k_seg_start=self.k_seg_start,
				   n_granules=len(self.c), frozen=self.frozen, wape_RUL=float(self.wape_RUL), wape_HI=float(self.wape_HI),
				   V_HI=float(self.V), cov_HI=float(self.cov), sp_HI=float(self.sp))
		self.segments[self.seg_name] = seg
		return seg

	def SimSequence(self, datasets, transfer='adapt', mode='interval', update_rls=True, on_end=None, check=None):
		'''
		Simula rolamentos em sequência com o mesmo modelo (grânulos + RNNs + modelo do erro + rho).
		datasets: lista de dicts {'name', 'X', 'Y', 'Z', 'J', 'L', 'ref'} (PrepareSeq em TedaOptimize_V4_5), em ordem.
		transfer: 'adapt'  -> o modelo continua aprendendo nos rolamentos seguintes;
		          'freeze' -> o modelo é congelado (Freeze) ao terminar o primeiro rolamento.
		mode: 'interval' (RULInterv) ou 'single' (RULSingle, predições pontuais, como em Optimize).
		update_rls: atualiza o modelo do erro/rho a cada passo (UpdateRLS(mode='HI')); Optimize não usa.
		Cada rolamento termina no EoL (J passos). Ao terminar: EndSegment (resultados em self.segments[name]) e
		on_end(self, name), ex.: salvar os gráficos (PlotView). check(self, b, j): chamado a cada passo (poda).
		'''
		if transfer not in ('adapt', 'freeze'): raise ValueError("transfer deve ser 'adapt' ou 'freeze'.")
		names = [d['name'] for d in datasets]
		if len(set(names)) != len(names): raise ValueError(f'Nomes de rolamento repetidos: {names}')
		for b, d in enumerate(datasets):
			if b > 0 and transfer == 'freeze': self.Freeze(True)
			self.NewSegment(d['name'], d['ref'], reset_state=b > 0)
			X, Y, Z = d['X'], d['Y'], d['Z']
			for j in range(d['J']):
				self.run(X[j])
				self.RUL_Prediction(Y[j], mode=mode, lim=d['L'])
				self.Adapt(Y[j], Z[j])
				if update_rls: self.UpdateRLS(mode='HI')
				if check is not None: check(self, b, j)
			self.EndSegment()
			if on_end is not None: on_end(self, d['name'])
		return self.segments

	def PlotView(self, identity='current'):
		'''
		Cópia rasa para PlotSimulation com apenas o rolamento atual (amostras com t >= início do rolamento, tempo local;
		sem NewSegment: toda a série). O modelo não é alterado.
		identity: 'current' -> grânulos atuais; cada amostra aparece no grânulo que a contém agora (após fusões);
		          'origin'  -> um grânulo por identidade de origem (ID na criação): cada amostra aparece no grânulo que a
		                       assimilou, mesmo que ele tenha sido fundido depois. Grânulos fundidos são desenhados com a
		                       forma (centro, raio) do momento da fusão e mantêm seus marcadores de RUL/HI do rolamento.
		Grânulos sem amostras do rolamento são omitidos.
		'''
		if identity not in ('current', 'origin'): raise ValueError("identity deve ser 'current' ou 'origin'.")
		v = copy.copy(self)
		in_seg = lambda t: t >= self.k_seg_start
		if identity == 'current':
			cs = []
			for cloud in self.c:
				pts = [(t, x, i) for t, x, i in zip(cloud.t, cloud.x, _XID(cloud)) if in_seg(t)]
				if not pts: continue
				cv = copy.copy(cloud)
				cv.t, cv.x, cv.xid = [t - self.k_seg for t, _, _ in pts], [x for _, x, _ in pts], [i for _, _, i in pts]
				cs.append(cv)
			v.c = np.array(cs, dtype=object)
			return v
		# identidade de origem: amostras de todos os grânulos atuais agrupadas pelo ID que as assimilou
		groups = {}
		for cloud in self.c:
			for t, x, i in zip(cloud.t, cloud.x, _XID(cloud)):
				if in_seg(t): groups.setdefault(i, []).append((t, x))
		obj = {c.ID: c for c in getattr(self, 'c_retired', [])}
		obj.update({c.ID: c for c in self.c})                 # grânulo vivo prevalece
		cs = []
		for i in sorted(groups, key=lambda g: (isinstance(g, str), g)):
			if i not in obj: continue
			src = obj[i]
			cv = copy.copy(src)
			pts = sorted(groups[i], key=lambda p: p[0])
			cv.t, cv.x, cv.xid = [t - self.k_seg for t, _ in pts], [x for _, x in pts], [i] * len(pts)
			if getattr(src, 'k_retired', np.inf) < self.k_seg_start:   # fundido em rolamento anterior: sem marcadores
				cv.t2, cv.rulM, cv.rulL, cv.rulU, cv.hiM = [], [], [], [], []
				cv.rulR, cv.rulP = np.array([]), np.array([])
			cs.append(cv)
		v.c = np.array(cs, dtype=object)
		return v

	def _RunFrozen(self, X):
		# Atribuição com estatísticas congeladas (mesmas expressões de run, sem gravar no grânulo)
		nc = len(self.c)
		tip, ok = np.zeros(nc), np.zeros(nc, dtype=bool)
		for i, cloud in enumerate(self.c):
			n = cloud.n + 1
			m = ((n-1)/n)*cloud.mean + (1/n)*X
			mT = ((n-1)/n) * cloud.meant + (X.dot(X))/n
			v = mT - m.dot(m)
			n_ecc = ((1/n) + ((m-X).T.dot(m-X))/(n*v))/2
			tip[i] = (1 - (((1/n) + ((m-X).T.dot(m-X))/((n*v)) - (1e-12))))/(self.k-2)
			ok[i] = n_ecc <= (self.m**2 + 1)/(2*n)
		alfa = np.where(ok, tip, 0.0)
		if self.wtaG and np.any(alfa > 0): alfa = np.where(alfa < np.max(alfa), 0, alfa)
		if not np.sum(alfa) > 0:                            # nenhum grânulo aceita: o mais típico
			alfa = np.zeros(nc); alfa[int(np.argmax(tip))] = 1.0
		self.alfa = alfa
		self.listIntersection = (alfa > 0).astype(int)
		if self.store:                                      # registro da amostra (só para os gráficos)
			for i, cloud in enumerate(self.c):
				if alfa[i] > 0:
					cloud.t.append(self.k)
					cloud.x.append(X)
					if hasattr(cloud, 'xid'): cloud.xid.append(cloud.ID)

	def run(self,X):
		self.alfa = np.zeros((np.size(self.c)),dtype=float)
		self.listIntersection = np.zeros((np.size(self.c)),dtype=int)
		if self.k==1 and not self.transfer:
			self.xR = X
			self.CreateCloud(X,self.k,self.store)
			self.alfa = np.ones(1)
			self.gm = DataCloud(X,(self.k-1),'GM',self.rho,self.m,nI=self.nI,nR=self.nR,nO=self.nOut,
					ηS=[self.N1,self.N2,self.N3],tau=self.tau,sd=self.sd,act=self.act,feedback=self.feedback,nPast=self.mO)

		elif self.k==2 and not self.transfer:
			self.c[0].AddDataClaud(X,self.k,self.store)
			v = self.c[0].variance
			n = self.c[0].n
			self.alfa = np.ones(1)
			self.c[0].AdjustBounds(X,self.k)
			
		elif self.k>=3 and self.frozen:
			self._RunFrozen(X)
			self.cycleP = np.append(self.cycleP,self.st+self.k-1)
			self.rulR_Train = np.append(self.rulR_Train,self.end-self.k)
			self.k=self.k+1
			return

		elif self.k>=3 or self.transfer:
			i=0
			createCloud = True
			params = [[] for l in range(len(self.c))]
			for i,cloud in enumerate(self.c):
				n = cloud.n +1
				m = ((n-1)/n)*cloud.mean + (1/n)*X
				mT = ((n-1)/n) * cloud.meant + (X.dot(X))/n
				v = mT-m.dot(m)
				ecc = ((1/n)+((m-X).T.dot(m-X))/(n*v))
				n_ecc = ((1/n)+((m-X).T.dot(m-X))/(n*v))/2
				n_tip = (1 - (((1/n)+((m-X).T.dot(m-X))/((n*v))-(1e-12))))/(self.k-2)
		
				if(n_ecc<=(self.m**2 +1)/(2*n)):
					
					createCloud= False
					params[i] = [n,m,mT,v,n_tip]
					self.alfa[i] = n_tip
					self.listIntersection[i] = 1
				else:
					self.alfa[i] = 0
					self.listIntersection[i] = 0
				i+=1

			if self.wtaG: 
				self.alfa = np.where(self.alfa<np.max(self.alfa),0,self.alfa)
				self.listIntersection = np.where(self.alfa>0,1,self.alfa)
			
			for i,cloud in enumerate(self.c):
				if self.alfa[i]>0:
					n,m,mT,v,n_tip = params[i]
					cloud.UpdateDataCloud(n,m,mT,v,n_tip,self.k,X,self.store)
					cloud.AdjustBounds(X,self.k)

			if(createCloud):
				self.CreateCloud(X,self.store)
				self.listIntersection = np.insert(self.listIntersection,i,1)
				self.matrixIntersection = np.pad(self.matrixIntersection, ((0,1),(0,1)), 'constant', constant_values=(0)) 
				self.c[-1].t.append(self.k)
				self.c[-1].R = 0
				
				self.DefRnnParams(self.c[-1])
				self.alfa = np.append(self.alfa,1)
			
			if not self.wtaG: 
				self.MergeClouds(X)

			self.CalculateSpCov()

		self.AdjustCloudMaster(self.k,X)
		self.cycleP = np.append(self.cycleP,self.st+self.k-1)
		self.rulR_Train = np.append(self.rulR_Train,self.end-self.k)
		self.k=self.k+1

	def restart(self,ref):
		self.eolX = 0
		self.HI = np.array([])
		self.DSI = np.array([])
		self.eolDSI = 0
		self.HIp = np.array([])
		self.cycleP=np.array([])

		# k continua global (tipicidade n_tip/(k-2), gm.n, cobertura dos grânulos): zerá-lo faz k-2 = 0 no 2º passo
		# (alfa = inf -> hiP = NaN, que contamina o RLS e o rho). Tempo, RUL real e pesos do WAPE ficam locais ao
		# novo rolamento pelo deslocamento k_seg (mesmo mecanismo de NewSegment)
		self.k_seg = self.k - 1
		self.k_seg_start = self.k
		self.t = np.array([])
		self.rulL = np.array([])
		self.rulP = np.array([])
		self.rulU = np.array([])
		self.rulR = np.array([])
		# 1 quando a trajetória (inferior, pontual, superior) não atinge o EoL e a RUL é truncada em lim
		self.rulCapL = np.array([], dtype=int)
		self.rulCapP = np.array([], dtype=int)
		self.rulCapU = np.array([], dtype=int)
		self.ref = ref
		self.rulR_Train = np.array([])
		self.lim = 160

		self.hiR = np.array([])
		self.hiP = np.array([])
		self.hiL = np.array([])
		self.hiU = np.array([])

		self.wape_RUL_hist = np.array([])
		self.wape_RUL = 0
		self.eRul_Sum = 0
		self.eRul_Diff = 0

		self.wape_HI_hist = np.array([])
		self.wape_HI = 0
		self.eHI_Sum = 0
		self.eHI_Diff = 0

		self.wape_HI_hist2 = np.array([])
		self.wape_HI2 = 0
		self.eHI_Sum2 = 0
		self.eHI_Diff2 = 0
		self.transfer = True

		for c in self.c:
			c.restart()