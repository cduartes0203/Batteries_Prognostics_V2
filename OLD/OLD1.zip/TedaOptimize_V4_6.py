'''
Otimização (Optuna) do AutoCloud_V4_6 com rho estático.

    Optimize    : um rolamento; minimiza WAPE_RUL + WAPE_HI (predições pontuais).
    OptimizeSeq : sequência de rolamentos assimilada pelo mesmo modelo (AutoCloud.restart entre rolamentos);
                  minimiza a média (ou soma) de WAPE_RUL + WAPE_HI final de cada rolamento.
    BestParams  : melhor linha de um Optimization.csv no formato de ParseParams.
    SimSeq      : simulação final de uma sequência de rolamentos com parâmetros fixos (mesmo procedimento de OptimizeSeq).

Nas duas otimizações, nLS = [min, max] executa n_study sessões de n_trials trials para CADA nº de camadas.
Uso no notebook (na pasta principal): from Functions.TedaOptimize_V4_6 import *
'''
import os
import time
import numpy as np
import pandas as pd
import optuna
from optuna.exceptions import TrialPruned
from Functions.AutoCloud_V4_6 import AutoCloud, RefEoL
from Functions.Utils import PrepareData, ParseParams
from Functions.Utils_OPT_R2 import EarlyStoppingCallback, SelSampler

__all__ = ['Optimize', 'OptimizeSeq', 'SeqTable', 'BestParams', 'SimSeq']


def _Storage(db_path, timeout=300, tries=10):
    # Banco SQLite do Optuna. timeout (s): espera pelo bloqueio do arquivo quando vários processos (janelas em paralelo)
    # gravam no mesmo banco, em vez de falhar com 'database is locked'. Banco novo aberto ao mesmo tempo por vários
    # processos: a criação das tabelas pode colidir ('table ... already exists'); nova tentativa encontra o banco pronto
    url = 'sqlite:///' + db_path.replace(os.sep, '/')
    for i in range(tries):
        try:
            return optuna.storages.RDBStorage(url, engine_kwargs={'connect_args': {'timeout': timeout}})
        except Exception:
            if i == tries - 1: raise
            time.sleep(1 + i)


def _Complete(study):
    return [t for t in study.trials if t.state == optuna.trial.TrialState.COMPLETE]

def Optimize(
        RS=None, HI=None,
        FileName=None,OptSampler=None,OptSeed=None,OptPrune=False,
        n_study=None,timeout=None,n_trials=None,
        patience=None,
        mS =None,nIS=None,nLS=None,nRS=None,nOS =None,mOS=None,
        N1S=None,N2S=None,N3S=None,τS =None,actS=None,
        feedback='symmetric',wtaG=False,wtaP=False,
        eol=0.3,w=1,
        OptReset=False,OptWarm=False,n_best=5,
        folder='Optimization'):

    '''
        Otimização mono-objetivo dos hiperparâmetros do AutoCloud_V4_6 [m, nI, nR, nO, mO, N1, N2, N3, τ, act]:
            minimiza WAPE_RUL + WAPE_HI de um rolamento.

        RS, HI : DSI (uma amostra por linha) e HI (uma coluna, ex.: PC1) do rolamento.
        eol    : limiar de EoL do HI;  w: janela do DSI em X_k (PrepareData).
        nO / mO: valores futuros / passados (incluindo h_k) de Z_k; h_{k+1} = Z_k[mO].
        Faixas de busca (xxS = [min, max]): mS, nIS, nRS (neurônios por camada), nOS, mOS,
            N1S, N2S, N3S (taxas de aprendizado, expoentes), τS, actS.
        nLS = [min, max]: nº de camadas. Cada valor nL = min, ..., max é otimizado separadamente, com n_study sessões
            de n_trials trials cada (ex.: nLS = [1, 3] -> n_trials para 1 camada, n_trials para 2 e n_trials para 3).
        OptSampler: None, Auto, GP, NSGAII, Random, TPE (SelSampler).

        feedback, wtaG, wtaP: configuração do modelo. Resultados em <folder>/<FileName>_<feedback>_G<wtaG>P<wtaP>/.
        Armazenamento persistente (SQLite, <folder>/<...>/optuna.db):
            para cada nL, cada uma das n_study sessões é um estudo independente chamado obj1_L<nL>-<nL>_s<i>,
            retomado a cada execução (n_trials = nº de trials NOVOS por execução, por sessão e por nL).
        OptReset: apaga e recria os estudos destas sessões (use após mudar o objetivo/código).
        OptWarm : enfileira o melhor trial das outras sessões da mesma configuração antes de otimizar.
        OptSeed : semente base; a sessão i do nL usa OptSeed + 100*nL + i (sessões independentes).
        n_best  : linhas mantidas por nº de camadas (nL) em mono/Optimization.csv, reconstruída com TODOS os trials
                  do banco (n_best menores erros de conjuntos de parâmetros distintos por nL; pior -> melhor em cada nL).

        Objetivo: mesma sequência de SimGranularRUL(mode_rul='single'), por passo k:
            run -> RUL_Prediction(mode='single') -> Adapt.
            Erro = teda.wape_RUL + teda.wape_HI (WAPE ponderados por k^2 do próprio AutoCloud; HI do passo k contra o real
            do passo k). Apenas predições pontuais: rho, intr_state e o modelo RLS do erro não afetam o objetivo
            (WAPE_HI2 e UpdateRLS são omitidos por isso).
    '''
    if RS is None or HI is None: raise ValueError('Informe RS e HI.')
    sig = np.asarray(HI, dtype=float)
    if sig.ndim > 1 and sig.shape[1] != 1: raise ValueError('HI deve ter uma única coluna.')
    sig = sig.ravel()
    FileName = f'{FileName}_{feedback}_G{int(wtaG)}P{int(wtaP)}'

    if n_study is None: n_study = 1
    if timeout is None: timeout = 60
    if n_trials is None and patience is None: n_trials = 25
    if patience is None:
        if n_trials is None or n_trials < 0.5e4: patience = 500
        else: patience = int(0.02*n_trials)

    if mS  is None: mS  = [1.75,4.25]
    if nIS is None: nIS = [2,40]
    if nLS is None: nLS = [1,5]
    if not 1 <= nLS[0] <= nLS[1]: raise ValueError(f'nLS inválido: requer 1 <= min <= max (recebido {nLS}).')
    if nRS is None: nRS = [1,60]
    if nOS is None: nOS = [1,40]
    if mOS is None: mOS = [0,40]
    if N1S is None: N1S = [1,9]
    if N2S is None: N2S = [1,9]
    if N3S is None: N3S = [1,9]
    if τS  is None: τS  = [1,25]
    if actS is None: actS = [0,1,2]

    # Limita nO para que o fluxo sempre alcance o EoL: a RUL é avaliada até a última amostra antes
    # do EoL em todos os trials (evita favorecer nO grande, que encurta o trecho avaliado)
    nO_max = len(sig) - int(np.argmax(sig <= eol))   # último instante k = K-1-nO >= iEoL-1
    if nOS[1] > nO_max:
        nOS = [nOS[0], nO_max]
        print(f'nO limitado a {nOS} para que o fluxo alcance o EoL.')
    if nOS[0] > nOS[1]: raise ValueError(f'nOS inválido: o limite para alcançar o EoL é nO <= {nO_max}.')

    prm_names = ['m', 'nI', 'nR', 'nO', 'mO', 'N1', 'N2', 'N3', 'TAU', 'activation']
    names = ['WAPE_RUL+WAPE_HI'] + prm_names
    study_dir = os.path.join(folder, FileName, 'mono')
    os.makedirs(study_dir, exist_ok=True)
    out_path = os.path.join(study_dir, 'Optimization.csv')

    # Armazenamento persistente: um banco SQLite por configuração; cada sessão é um estudo independente e retomável
    db_path = os.path.abspath(os.path.join(folder, FileName, 'optuna.db'))
    storage = _Storage(db_path)
    prefix = 'obj1_'
    summary = []
    nL_cur = None                                   # nº de camadas da rodada atual (laço abaixo)

    def objective(trial):
        m = trial.suggest_float('m', mS[0], mS[1],step=0.25)
        nI = trial.suggest_int('nI', nIS[0], nIS[1])
        n_layers = trial.suggest_int('n_layers', nL_cur, nL_cur)   # fixo na rodada (registrado no banco)
        nR = [trial.suggest_int(f'nR_layer_{l}', nRS[0], nRS[1]) for l in range(n_layers)]
        nO = trial.suggest_int('nO', nOS[0], nOS[1])
        N1 = trial.suggest_int('N1', N1S[0], N1S[1])
        N2 = trial.suggest_int('N2', N2S[0], N2S[1])
        N3 = trial.suggest_int('N3', N3S[0], N3S[1])
        τ = trial.suggest_int('τ', τS[0], τS[1])
        act = trial.suggest_int('act', actS[0], actS[1])
        mO = trial.suggest_int('mO', mOS[0], mOS[1])
        if mO > nI: raise TrialPruned()

        X, Y, Z, kX = PrepareData(RS, HI, w, nI, nO, mO)
        try: ref, J, L = RefEoL(sig, eol, kX, strict=True)
        except ValueError: raise TrialPruned()   # o fluxo não alcança o EoL (não deve ocorrer com nOS limitado)

        teda = AutoCloud(m=m,nI=nI,nR=nR,nO=nO,mO=mO,ηS=[N1,N2,N3],act=act,
                         tau=τ,eol=eol,ref=ref,wtaG=wtaG,wtaP=wtaP,feedback=feedback)
        for j,_ in enumerate(X[:J]):
            teda.run(X[j])
            teda.RUL_Prediction(Y[j],mode='single',lim=L)   # WAPE_RUL do passo
            teda.Adapt(Y[j],Z[j])                            # WAPE_HI do passo e treino das RNNs
            wR, wH = teda.wape_RUL, teda.wape_HI

            if not np.isfinite(teda.hiP[-1]): raise TrialPruned()
            if not OptPrune: continue

            if j >=40 and j%5==0:
                if wR > 0.6: raise TrialPruned()
                if wH > 0.3: raise TrialPruned()

            if j%35==0:
                trial.report(wR+wH, j)
                if trial.should_prune():
                    raise TrialPruned()

        return teda.wape_RUL + teda.wape_HI

    for nL in range(nLS[0], nLS[1] + 1):
        nL_cur = nL
        base_name = f'{prefix}L{nL}-{nL}'
        print(f'\n===== nº de camadas: {nL} ({n_study} sessão(ões) x {n_trials} trials) =====')
        for i in range(n_study):
            study_name = f'{base_name}_s{i+1}'
            print(f'iteration: {i+1} | study: {study_name}')
            if OptReset and study_name in optuna.get_all_study_names(storage):
                optuna.delete_study(study_name=study_name, storage=storage)
                print(f'  {study_name}: estudo anterior apagado (OptReset=True).')

            # Sessões independentes: sementes distintas quando OptSeed é informado
            seed = None if OptSeed is None else OptSeed + 100*nL + i
            study = optuna.create_study(study_name=study_name,storage=storage,load_if_exists=True,direction='minimize',
                                        pruner=optuna.pruners.HyperbandPruner(),sampler=SelSampler(mode=OptSampler,seed=seed))
            n_prev, done = len(study.trials), _Complete(study)

            if OptWarm:
                # Começa pelo melhor trial das outras sessões desta configuração
                others = [n for n in optuna.get_all_study_names(storage) if n.startswith(base_name + '_s') and n != study_name]
                cand = [t for n in others for t in _Complete(optuna.load_study(study_name=n, storage=storage))]
                if cand:
                    best = min(cand, key=lambda t: t.value)
                    study.enqueue_trial(best.params, skip_if_exists=True)
                    print(f'  OptWarm: melhor trial das outras sessões enfileirado (score {best.value:.4f}).')

            # Parada antecipada conta trials sem superar o melhor resultado já armazenado
            callback = EarlyStoppingCallback(patience=patience, context={
                'nL': [nL, nL], 'session': i+1, 'n_study': n_study, 'study_name': study_name, 'config': FileName,
                'n_prev': n_prev, 'n_trials': n_trials, 'timeout': timeout,
                'storage': storage, 'prefix': prefix})   # melhor trial por nL (todas as sessões/fases)
            if done:
                best_prev = min(done, key=lambda t: t.value)
                callback.best_score = best_prev.value
                callback.best_number = best_prev.number
                callback.best_trial_info = f'Trial #{best_prev.number:03d} (sessões anteriores) | Score: {best_prev.value:.4f} | Params: {best_prev.params}'
            print(f'  {study_name}: {n_prev} trials armazenados' + (f', melhor {callback.best_score:.4f}' if done else ''))
            study.optimize(objective, n_trials=None if n_trials is None else int(n_trials), timeout=timeout, callbacks=[callback])

            done = _Complete(study)
            summary.append((study_name, n_prev, len(study.trials), min(t.value for t in done) if done else float('nan')))

    print('\nResumo das sessões (banco: ' + db_path + ')')
    for name, n0, n1, best in summary:
        print(f'  {name}: {n0} -> {n1} trials | melhor {best:.4f}')

    # Tabela reconstruída do banco: todos os trials concluídos (todas as sessões, fases e nº de camadas),
    # mantendo para cada nL os n_best menores erros
    rows = []
    for name in optuna.get_all_study_names(storage):
        if not name.startswith(prefix): continue
        for t in _Complete(optuna.load_study(study_name=name, storage=storage)):
            p = t.params
            nR_list = [p[f'nR_layer_{l}'] for l in range(p['n_layers'])]
            prm = [p['m'],p['nI'],str(nR_list),p['nO'],p['mO'],p['N1'],p['N2'],p['N3'],p['τ'],p['act']]
            rows.append([t.value] + prm + [p['n_layers']])
    if not rows:
        print('Nenhum trial concluído: Optimization.csv não foi gerado.')
        return pd.DataFrame(columns=names)
    df_all = pd.DataFrame(rows, columns=names + ['_nL'])
    # Mesmo conjunto de parâmetros conta uma vez (mantém o menor erro)
    df_all = df_all.sort_values(names[0]).drop_duplicates(subset=prm_names)
    df_stdy = df_all.groupby('_nL', group_keys=False).head(n_best)
    df_stdy = df_stdy.sort_values(['_nL', names[0]], ascending=[True, False])

    print(f'\nOptimization.csv: {n_best} melhores por nº de camadas ({out_path})')
    for nL_, grp in df_stdy.groupby('_nL'):
        print(f'  nL={nL_}: {len(grp)} linhas | melhor {grp[names[0]].min():.4f} | pior mantido {grp[names[0]].max():.4f}')

    df_stdy = df_stdy.drop(columns=['_nL']).reset_index(drop=True)
    df_stdy.to_csv(out_path, index=False)
    return df_stdy


def OptimizeSeq(
        data=None,
        FileName=None,OptSampler=None,OptSeed=None,OptPrune=False,
        n_study=None,timeout=None,n_trials=None,
        patience=None,
        mS =None,nIS=None,nLS=None,nRS=None,nOS =None,mOS=None,
        N1S=None,N2S=None,N3S=None,τS =None,actS=None,
        feedback='symmetric',wtaG=False,wtaP=False,
        eol=0.3,w=1,agg='mean',state='keep',
        OptReset=False,OptWarm=False,n_best=5,
        folder='Optimization',write_table=True):

    '''
        Versão de Optimize para uma SEQUÊNCIA de rolamentos assimilada pelo mesmo modelo (AutoCloud_V4_6.restart):
            o 1º rolamento é simulado até o EoL; antes de cada rolamento seguinte, teda.restart(ref) zera RUL/HI/WAPE e
            mantém grânulos, RNNs e modelo do erro, e a simulação prossegue (mesmo procedimento da última célula).

        data: lista ordenada de (nome, RS, HI), ex.: [('B1_1', RS11, HI11['PC1']), ('B1_2', RS12, HI12['PC1'])].
        agg : 'mean' -> minimiza a média, sobre os rolamentos, de (WAPE_RUL + WAPE_HI) final de cada rolamento;
              'sum'  -> minimiza a soma.
        state: estado recorrente das RNNs no início de cada rolamento seguinte (teda.restart):
              'keep' (estado do fim do rolamento anterior), 'reset' (estado inicial) ou 'fixed' (equilíbrio para a
              primeira janela Y[0] do novo rolamento). Pastas: ..._restart_... ('keep') ou ..._restart-<state>_...
        Cada rolamento usa o próprio HI em RefEoL (ref, J, L locais). WAPE_RUL e WAPE_HI de cada rolamento são os valores
        finais (ponderados por (k - k_seg)^2, locais ao rolamento), lidos antes do restart seguinte.
        Demais argumentos: iguais a Optimize (faixas de busca, sessões, nLS com n_trials por nº de camadas, OptPrune,
        OptReset, OptWarm, n_best, folder).

        Resultados em <folder>/<FileName>_<B1_1-B1_2>_restart[-<state>]_<feedback>_G<wtaG>P<wtaP>/ (optuna.db e mono/Optimization.csv).
        Optimization.csv: coluna do objetivo (WAPE_mean ou WAPE_sum), os 10 parâmetros (mesmo formato de Optimize/ParseParams)
        e WAPE_RUL_<nome>, WAPE_HI_<nome> de cada rolamento.
        OptPrune: poda ao fim de cada rolamento (trial.report do objetivo parcial) e por limiares dentro do rolamento.
        write_table: False = não grava o Optimization.csv ao fim (execuções em paralelo no mesmo banco: a tabela é
              gerada uma única vez com SeqTable depois que todas terminam). Retorna None nesse caso.
    '''
    if not data or len(data) < 2: raise ValueError('Informe data com pelo menos dois rolamentos: [(nome, RS, HI), ...].')
    if agg not in ('mean', 'sum'): raise ValueError("agg deve ser 'mean' ou 'sum'.")
    if state not in ('keep', 'reset', 'fixed'): raise ValueError("state deve ser 'keep', 'reset' ou 'fixed'.")
    names_b = [str(d[0]) for d in data]
    if len(set(names_b)) != len(names_b): raise ValueError('Nomes de rolamentos repetidos em data.')
    sigs = []
    for nm, RS_b, HI_b in data:
        s_ = np.asarray(HI_b, dtype=float)
        if s_.ndim > 1 and s_.shape[1] != 1: raise ValueError(f'{nm}: HI deve ter uma única coluna.')
        sigs.append(s_.ravel())
    tag_rs = 'restart' if state == 'keep' else f'restart-{state}'   # 'keep': mesma pasta das versões anteriores
    FileName = f'{FileName}_{"-".join(names_b)}_{tag_rs}_{feedback}_G{int(wtaG)}P{int(wtaP)}'

    if n_study is None: n_study = 1
    if timeout is None: timeout = 60
    if n_trials is None and patience is None: n_trials = 25
    if patience is None:
        if n_trials is None or n_trials < 0.5e4: patience = 500
        else: patience = int(0.02*n_trials)

    if mS  is None: mS  = [1.75,4.25]
    if nIS is None: nIS = [2,40]
    if nLS is None: nLS = [1,5]
    if not 1 <= nLS[0] <= nLS[1]: raise ValueError(f'nLS inválido: requer 1 <= min <= max (recebido {nLS}).')
    if nRS is None: nRS = [1,60]
    if nOS is None: nOS = [1,40]
    if mOS is None: mOS = [0,40]
    if N1S is None: N1S = [1,9]
    if N2S is None: N2S = [1,9]
    if N3S is None: N3S = [1,9]
    if τS  is None: τS  = [1,25]
    if actS is None: actS = [0,1,2]

    # nO limitado para que o fluxo de TODOS os rolamentos alcance o EoL
    for nm, s_ in zip(names_b, sigs):
        if not np.any(s_ <= eol): raise ValueError(f'{nm}: o HI nunca atinge o EoL.')
    nO_max = min(len(s_) - int(np.argmax(s_ <= eol)) for s_ in sigs)
    if nOS[1] > nO_max:
        nOS = [nOS[0], nO_max]
        print(f'nO limitado a {nOS} para que o fluxo de todos os rolamentos alcance o EoL.')
    if nOS[0] > nOS[1]: raise ValueError(f'nOS inválido: o limite para alcançar o EoL é nO <= {nO_max}.')

    obj_name = f'WAPE_{agg}'
    study_dir = os.path.join(folder, FileName, 'mono')
    os.makedirs(study_dir, exist_ok=True)
    out_path = os.path.join(study_dir, 'Optimization.csv')

    db_path = os.path.abspath(os.path.join(folder, FileName, 'optuna.db'))
    storage = _Storage(db_path)
    prefix = f'seq{agg}_'                          # objetivos 'mean' e 'sum' não se misturam no mesmo banco
    summary = []
    nL_cur = None                                   # nº de camadas da rodada atual (laço abaixo)
    Agg = (lambda v: float(np.mean(v))) if agg == 'mean' else (lambda v: float(np.sum(v)))

    def objective(trial):
        m = trial.suggest_float('m', mS[0], mS[1],step=0.0125)
        nI = trial.suggest_int('nI', nIS[0], nIS[1])
        n_layers = trial.suggest_int('n_layers', nL_cur, nL_cur)   # fixo na rodada (registrado no banco)
        nR = [trial.suggest_int(f'nR_layer_{l}', nRS[0], nRS[1]) for l in range(n_layers)]
        nO = trial.suggest_int('nO', nOS[0], nOS[1])
        N1 = trial.suggest_int('N1', N1S[0], N1S[1])
        N2 = trial.suggest_int('N2', N2S[0], N2S[1])
        N3 = trial.suggest_int('N3', N3S[0], N3S[1])
        τ = trial.suggest_int('τ', τS[0], τS[1])
        act = trial.suggest_int('act', actS[0], actS[1])
        mO = trial.suggest_int('mO', mOS[0], mOS[1])
        if mO > nI: raise TrialPruned()

        # Janelas, EoL e RUL real de cada rolamento (com o próprio HI)
        ds = []
        for (nm, RS_b, HI_b), s_ in zip(data, sigs):
            X, Y, Z, kX = PrepareData(RS_b, HI_b, w, nI, nO, mO)
            try: ref, J, L = RefEoL(s_, eol, kX, strict=True)
            except ValueError: raise TrialPruned()
            ds.append((nm, X, Y, Z, ref, J, L))

        teda = AutoCloud(m=m,nI=nI,nR=nR,nO=nO,mO=mO,ηS=[N1,N2,N3],act=act,
                         tau=τ,eol=eol,ref=ds[0][4],wtaG=wtaG,wtaP=wtaP,feedback=feedback)
        errs = []
        for b, (nm, X, Y, Z, ref, J, L) in enumerate(ds):
            if b > 0: teda.restart(ref, state=state, x0=Y[0])   # mantém grânulos, pesos e modelo do erro; zera RUL/HI/WAPE
            for j in range(J):
                teda.run(X[j])
                teda.RUL_Prediction(Y[j],mode='single',lim=L)   # WAPE_RUL do passo
                teda.Adapt(Y[j],Z[j])                            # WAPE_HI do passo e treino das RNNs
                if not np.isfinite(teda.hiP[-1]): raise TrialPruned()
                if OptPrune and j >= 40 and j%5 == 0:
                    if teda.wape_RUL > 0.6 or teda.wape_HI > 0.3: raise TrialPruned()
            wR, wH = float(teda.wape_RUL), float(teda.wape_HI)
            trial.set_user_attr(f'WAPE_RUL_{nm}', wR)
            trial.set_user_attr(f'WAPE_HI_{nm}', wH)
            errs.append(wR + wH)
            if OptPrune:
                trial.report(Agg(errs), b)           # objetivo parcial ao fim de cada rolamento
                if trial.should_prune(): raise TrialPruned()
        return Agg(errs)

    for nL in range(nLS[0], nLS[1] + 1):
        nL_cur = nL
        base_name = f'{prefix}L{nL}-{nL}'
        print(f'\n===== nº de camadas: {nL} ({n_study} sessão(ões) x {n_trials} trials) | {" -> ".join(names_b)} | {obj_name} =====')
        for i in range(n_study):
            study_name = f'{base_name}_s{i+1}'
            print(f'iteration: {i+1} | study: {study_name}')
            if OptReset and study_name in optuna.get_all_study_names(storage):
                optuna.delete_study(study_name=study_name, storage=storage)
                print(f'  {study_name}: estudo anterior apagado (OptReset=True).')

            seed = None if OptSeed is None else OptSeed + 100*nL + i
            study = optuna.create_study(study_name=study_name,storage=storage,load_if_exists=True,direction='minimize',
                                        pruner=optuna.pruners.HyperbandPruner(),sampler=SelSampler(mode=OptSampler,seed=seed))
            n_prev, done = len(study.trials), _Complete(study)

            if OptWarm:
                others = [n for n in optuna.get_all_study_names(storage) if n.startswith(base_name + '_s') and n != study_name]
                cand = [t for n in others for t in _Complete(optuna.load_study(study_name=n, storage=storage))]
                if cand:
                    best = min(cand, key=lambda t: t.value)
                    study.enqueue_trial(best.params, skip_if_exists=True)
                    print(f'  OptWarm: melhor trial das outras sessões enfileirado (score {best.value:.4f}).')

            callback = EarlyStoppingCallback(patience=patience, context={
                'nL': [nL, nL], 'session': i+1, 'n_study': n_study, 'study_name': study_name, 'config': FileName,
                'n_prev': n_prev, 'n_trials': n_trials, 'timeout': timeout,
                'storage': storage, 'prefix': prefix})
            if done:
                best_prev = min(done, key=lambda t: t.value)
                callback.best_score = best_prev.value
                callback.best_number = best_prev.number
                callback.best_trial_info = f'Trial #{best_prev.number:03d} (sessões anteriores) | Score: {best_prev.value:.4f} | Params: {best_prev.params}'
            print(f'  {study_name}: {n_prev} trials armazenados' + (f', melhor {callback.best_score:.4f}' if done else ''))
            study.optimize(objective, n_trials=None if n_trials is None else int(n_trials), timeout=timeout, callbacks=[callback])

            done = _Complete(study)
            summary.append((study_name, n_prev, len(study.trials), min(t.value for t in done) if done else float('nan')))

    print('\nResumo das sessões (banco: ' + db_path + ')')
    for name, n0, n1, best in summary:
        print(f'  {name}: {n0} -> {n1} trials | melhor {best:.4f}')

    if not write_table:
        print('write_table=False: Optimization.csv não foi atualizado (use SeqTable ao fim de todas as janelas).')
        return None
    return SeqTable(db_path, names_b, agg=agg, n_best=n_best, out_path=out_path)


def SeqTable(db_path, names_b, agg='mean', n_best=5, out_path=None):
    '''
    Reconstrói o Optimization.csv de OptimizeSeq a partir do banco do Optuna (todos os estudos seq<agg>_*), sem executar
    trials: n_best melhores por nº de camadas, com o WAPE de cada rolamento. Usado ao fim de OptimizeSeq e, nas execuções
    em paralelo (uma janela por faixa de nº de camadas, mesmo banco), uma única vez depois que todas as janelas terminam.
        db_path : caminho do optuna.db.
        names_b : nomes dos rolamentos, na ordem (ex.: ['B1_1', 'B1_2']).
        out_path: caminho do .csv; None = <pasta do banco>/mono/Optimization.csv.
    '''
    if agg not in ('mean', 'sum'): raise ValueError("agg deve ser 'mean' ou 'sum'.")
    if not os.path.exists(db_path): raise FileNotFoundError(f'{db_path} não encontrado.')
    if out_path is None:
        os.makedirs(os.path.join(os.path.dirname(db_path), 'mono'), exist_ok=True)
        out_path = os.path.join(os.path.dirname(db_path), 'mono', 'Optimization.csv')
    storage = _Storage(db_path)
    prefix = f'seq{agg}_'
    obj_name = f'WAPE_{agg}'
    prm_names = ['m', 'nI', 'nR', 'nO', 'mO', 'N1', 'N2', 'N3', 'TAU', 'activation']
    seg_cols = [c for nm in names_b for c in (f'WAPE_RUL_{nm}', f'WAPE_HI_{nm}')]
    names = [obj_name] + prm_names

    # Tabela reconstruída do banco: n_best melhores por nº de camadas, com o WAPE de cada rolamento
    rows = []
    for name in optuna.get_all_study_names(storage):
        if not name.startswith(prefix): continue
        for t in _Complete(optuna.load_study(study_name=name, storage=storage)):
            p = t.params
            nR_list = [p[f'nR_layer_{l}'] for l in range(p['n_layers'])]
            prm = [p['m'],p['nI'],str(nR_list),p['nO'],p['mO'],p['N1'],p['N2'],p['N3'],p['τ'],p['act']]
            rows.append([t.value] + prm + [t.user_attrs.get(c, np.nan) for c in seg_cols] + [p['n_layers']])
    if not rows:
        print('Nenhum trial concluído: Optimization.csv não foi gerado.')
        return pd.DataFrame(columns=names + seg_cols)
    df_all = pd.DataFrame(rows, columns=names + seg_cols + ['_nL'])
    df_all = df_all.sort_values(obj_name).drop_duplicates(subset=prm_names)
    df_stdy = df_all.groupby('_nL', group_keys=False).head(n_best)
    df_stdy = df_stdy.sort_values(['_nL', obj_name], ascending=[True, False])

    print(f'\nOptimization.csv: {n_best} melhores por nº de camadas ({out_path})')
    for nL_, grp in df_stdy.groupby('_nL'):
        print(f'  nL={nL_}: {len(grp)} linhas | melhor {grp[obj_name].min():.4f} | pior mantido {grp[obj_name].max():.4f}')

    df_stdy = df_stdy.drop(columns=['_nL']).reset_index(drop=True)
    df_stdy.to_csv(out_path, index=False)
    return df_stdy


def BestParams(csv_path):
    '''Melhor linha (menor erro, 1ª coluna) de um Optimization.csv de Optimize/OptimizeSeq, no formato de ParseParams:
    [m, nI, nR, nO, mO, N1, N2, N3, τ, act].'''
    dfP = pd.read_csv(csv_path).iloc[:, :11]
    return ParseParams(dfP.sort_values(dfP.columns[0], ascending=True).iloc[0, 1:].values)


def SimSeq(params, data, state='keep', mode_rul='interval', rho=0.1, intr_state='carry',
           eol=0.3, w=1, feedback='symmetric', wtaG=False, wtaP=False, store=True, on_end=None):
    '''
    Simula uma sequência de rolamentos com parâmetros fixos, no mesmo procedimento de OptimizeSeq:
        1º rolamento até o EoL (SimGranularRUL); antes de cada rolamento seguinte, teda.restart(ref, state, Y[0]).
    params  : [m, nI, nR, nO, mO, N1, N2, N3, τ, act] (ParseParams/BestParams).
    data    : lista ordenada de (nome, RS, HI).
    mode_rul: 'interval' (RUL e HI intervalares, com rho e intr_state) ou 'single' (apenas pontuais).
    on_end  : função opcional on_end(teda, nome, i) chamada ao fim de cada rolamento (gráficos, registros).
    Retorna (teda, linhas): o modelo ao fim da sequência e uma lista com as métricas finais de cada rolamento.
    '''
    m, nI, nR, nO, mO, N1, N2, N3, τ, act = params
    teda, rows = None, []
    for i, (nm, RS_b, HI_b) in enumerate(data):
        sig = np.asarray(HI_b, dtype=float).ravel()
        X, Y, Z, kX = PrepareData(RS_b, HI_b, w, nI, nO, mO)
        ref, J, L = RefEoL(sig, eol, kX)
        if i == 0:
            teda = AutoCloud(m=m, nI=nI, nR=nR, nO=nO, mO=mO, ηS=[N1, N2, N3], tau=τ, eol=eol, ref=ref, act=act,
                             wtaG=wtaG, wtaP=wtaP, store=store, feedback=feedback, rho=rho, intr_state=intr_state)
        else:
            teda.restart(ref, state=state, x0=Y[0])
        teda.SimGranularRUL(J, L, X, Y, Z, mode_rul)
        rows.append(dict(ordem=i + 1, rolamento=nm, passos=len(teda.rulP), granulos=len(teda.c),
                         WAPE_RUL=float(teda.wape_RUL), WAPE_HI=float(teda.wape_HI),
                         V_HI=float(teda.V), cov_HI=float(teda.cov), sp_HI=float(teda.sp)))
        if on_end is not None: on_end(teda, nm, i + 1)
    return teda, rows
